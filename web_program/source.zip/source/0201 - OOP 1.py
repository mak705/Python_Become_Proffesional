
class Program():

    def __init__(self, *args, **kwargs):

        self.lang = input("What Language?: ")
        self.version = float(input("Version?: "))
        self.skill = input("What skill level?: ")


p1 = Program()
        

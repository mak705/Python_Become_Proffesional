from sample_module import *

output('Hello')


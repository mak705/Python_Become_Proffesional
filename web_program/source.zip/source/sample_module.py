

def output(text):
    print(text)

    
    
